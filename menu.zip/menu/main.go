package main

import (
	"fmt"
	"os"
	"strings"
)

var (
	SEARCH string = "https://raw.githubusercontent.com/Fahmi-XD/ip/refs/heads/main/ip.txt";
)

func main() {
	// fmt.Println("Memeriksa semua file untuk di ganti")

	file, err := os.ReadDir("./")
	if err != nil {
		fmt.Println(err)
	}

	for _, v := range file {
		// fmt.Println("Memeriksa file: ", v.Name())

		content, err := os.ReadFile(v.Name())
		if err != nil {
			fmt.Println(err)
		}

		if strings.Contains(string(content), SEARCH) {
			fmt.Println("Ada di file: ", v.Name())
		}
	}
}